<template>
  <div class=" relative top-0 left-0 w-full">
    <div class=" w-full h-5px bg-gradient-to-r from-green-400 to-blue-500" />
    <div class=" h-67px flex items-center rounded-b-xl bg-white shadow-header">
      <NuxtLink class=" absolute right-5 h-5 font-lato font-semibold text-third text-sm tracking-0.84px " to="/login">Login</NuxtLink>
    </div>
  </div>
</template>

<template>
  <div class=" fixed bottom-0 w-full flex justify-around items-center h-24 rounded-t-xl shadow-footer bg-white">
    <div class=" flex justify-around items-center w-320px h-10 text-sm text-teal-100 font-lato text-white tracking-0.84px bg-gradient-to-r from-third to-third-g rounded-xl">Kostenlos Registrieren</div>
  </div>
</template>

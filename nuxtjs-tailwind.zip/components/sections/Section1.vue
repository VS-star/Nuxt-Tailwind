<template>
  <div class="section-content flex flex-wrap justify-around">
    <div class="section-title flex justify-around flex-wrap flex-col tracking-normal text-21px text-third font-lato font-medium">
      <p class="h-6"> Drei einfache Schritte </p>
      <p class="h-6"> zu deinem neuen Job </p>
    </div>
    <div class="section-first flex w-full h-250px -mb-2.5	">
      <img
        class="section-first-logo absolute mt-5"
        src="../../assets/img/undraw_Profile_data_re_v81r_2x.png"
        width="220px"
        height="145px"
        alt=""
      />
      <p class="section-first-num h-40 mt-70px font-lato text-130px text-first tracking-normal absolute">1.</p>
      <p class="section-first-text absolute font-lato text-first text-base tracking-0.47px pr-8 mt-205px ">Erstellen dein Lebenslauf</p>
    </div>
    <div class="section-second flex w-full h-370px mb-2.5 ">
      <img
        src="../../assets/img/back2.png"
        alt=""
        width="100%"
        height="100%"
      />
      <img
        class="section-second-logo absolute mt-182px"
        src="../../assets/img/undraw_task_31wc@2x.png"
        width="180px"
        height="127px"
        alt=""
      />
      <p class="section-second-num h-40 mt-2.5 font-lato text-130px text-first tracking-normal absolute">2.</p>
      <p class="section-second-text absolute font-lato text-first text-base tracking-0.47px mt-140px ">Erstellen dein Lebenslauf</p>
    </div>
    <div class="section-third flex w-full h-250px mb-48">
      <img
        class="section-third-logo absolute mt-24"
        src="../../assets/img/undraw_personal_file_222m@2x.png"
        width="280px"
        height="210px"
        alt=""
      />
      <p class="section-third-num h-40 -mt-40px font-lato text-130px text-first tracking-normal absolute">3.</p>
      <p class="section-third-text absolute font-lato text-first text-base tracking-0.47px mt-9 ">Mit nur einem Klick bewerben</p>
    </div>
  </div>
</template>